package com.example.applocker

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

// بيكتشف التطبيق المفتوح لحظياً (من غير polling) ويعرض شاشة القفل.
// وفي الوضع الصارم بيقفل نافذة "Check background activity" اللي فيها زرار Stop.
class LockAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: LockOverlay? = null
    private var current: String? = null
    private var homePkgs: Set<String> = emptySet()
    private var imePkgs: Set<String> = emptySet()
    private var ticks = 0

    private val tick = object : Runnable {
        override fun run() {
            overlay?.updateText(subText())
            if (++ticks % 5 == 0) ensureBlockService()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onServiceConnected() {
        instance = this
        homePkgs = Prefs.homePackages(this)
        imePkgs = try {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .enabledInputMethodList.map { it.packageName }.toSet()
        } catch (_: Exception) {
            emptySet()
        }
        overlay = LockOverlay(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
        ensureBlockService()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""
        val strict = Prefs.isStrict(this)

        if (!Prefs.enabled(this) && !strict) {
            overlay?.hide()
            return
        }

        if (pkg == "com.android.systemui") {
            if (strict && Prefs.blockSettings(this)) {
                if (looksLikeStopDialog()) performGlobalAction(GLOBAL_ACTION_HOME)
                else handler.postDelayed({
                    if (looksLikeStopDialog()) performGlobalAction(GLOBAL_ACTION_HOME)
                }, 400)
            }
            return
        }
        if (pkg == "android" || pkg in imePkgs) return
        if (cls.startsWith("android.widget.")) return
        if (pkg == packageName && !cls.endsWith("MainActivity")) return

        current = pkg
        evaluate()
    }

    private fun evaluate() {
        val pkg = current ?: return
        val blocked = if (pkg == packageName || pkg in homePkgs) {
            false
        } else {
            val set = HashSet(Prefs.blocked(this))
            if (Prefs.isStrict(this) && Prefs.blockSettings(this)) set.addAll(BlockService.SETTINGS_PKGS)
            pkg in set
        }
        if (blocked) overlay?.show(subText()) else overlay?.hide()
    }

    private fun subText(): String =
        if (Prefs.isStrict(this)) "الوضع الصارم شغال\nباقي " + Prefs.remainingText(this)
        else "ركّز في مهامك 💪"

    // نافذة Check background activity: فيها اسم التطبيق بالظبط + زرار Stop
    private fun looksLikeStopDialog(): Boolean {
        val root = rootInActiveWindow ?: return false
        val label = getString(R.string.app_name)
        val hasName = root.findAccessibilityNodeInfosByText(label)
            .any { it.text?.toString()?.trim() == label }
        if (!hasName) return false
        return STOP_WORDS.any { w ->
            root.findAccessibilityNodeInfosByText(w)
                .any { it.text?.toString()?.trim().equals(w, ignoreCase = true) }
        }
    }

    private fun ensureBlockService() {
        if ((Prefs.enabled(this) || Prefs.isStrict(this)) && !BlockService.running) {
            try {
                startForegroundService(Intent(this, BlockService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        handler.removeCallbacks(tick)
        overlay?.hide()
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var instance: LockAccessibilityService? = null
        private val STOP_WORDS = listOf("Stop", "إيقاف", "إيقاف إجباري", "Force stop")
    }
}
