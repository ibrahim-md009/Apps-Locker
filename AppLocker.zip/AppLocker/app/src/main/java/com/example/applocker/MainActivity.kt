package com.example.applocker

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class AppItem(val pkg: String, val label: String, val icon: Drawable)
    private class Holder(val icon: ImageView, val cb: CheckBox)

    private val apps = ArrayList<AppItem>()
    private val selected = HashSet<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var lastStrict: Boolean? = null

    private lateinit var permsTv: TextView
    private lateinit var btnUsage: Button
    private lateinit var btnOverlay: Button
    private lateinit var toggleBtn: Button
    private lateinit var etMinutes: EditText
    private lateinit var cbSettings: CheckBox
    private lateinit var strictBtn: Button
    private lateinit var strictTv: TextView
    private lateinit var adapter: BaseAdapter

    private val ticker = object : Runnable {
        override fun run() {
            updateUi()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(Prefs.blocked(this))

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val list = ListView(this)
        list.addHeaderView(buildHeader(), null, false)

        adapter = object : BaseAdapter() {
            override fun getCount(): Int = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val h: Holder
                val v: View
                if (convertView == null) {
                    val row = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(16), dp(6), dp(16), dp(6))
                    }
                    val ic = ImageView(this@MainActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
                    }
                    val cb = CheckBox(this@MainActivity).apply {
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        setPadding(dp(8), 0, 0, 0)
                    }
                    row.addView(ic)
                    row.addView(cb)
                    h = Holder(ic, cb)
                    row.tag = h
                    v = row
                } else {
                    v = convertView
                    h = convertView.tag as Holder
                }

                val item = apps[position]
                h.icon.setImageDrawable(item.icon)
                h.cb.setOnCheckedChangeListener(null)
                h.cb.text = item.label
                h.cb.isChecked = item.pkg in selected
                h.cb.isEnabled = !Prefs.isStrict(this@MainActivity)
                h.cb.setOnCheckedChangeListener { _, on ->
                    if (on) selected.add(item.pkg) else selected.remove(item.pkg)
                    Prefs.setBlocked(this@MainActivity, selected)
                }
                return v
            }
        }
        list.adapter = adapter
        setContentView(list)
        loadApps()
    }

    private fun buildHeader(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(8))
        }

        fun tv(t: String, size: Float = 15f, bold: Boolean = false): TextView =
            TextView(this).apply {
                text = t
                textSize = size
                if (bold) setTypeface(typeface, Typeface.BOLD)
            }

        col.addView(tv("🔒 قفل التطبيقات", 24f, true))

        permsTv = tv("")
        permsTv.setPadding(0, dp(12), 0, dp(4))
        col.addView(permsTv)

        btnUsage = Button(this).apply {
            text = "1) فعّل Usage Access"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        col.addView(btnUsage)

        btnOverlay = Button(this).apply {
            text = "2) فعّل العرض فوق التطبيقات"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        col.addView(btnOverlay)

        toggleBtn = Button(this).apply { setOnClickListener { onToggle() } }
        col.addView(toggleBtn)

        val strictTitle = tv("⏳ الوضع الصارم", 18f, true)
        strictTitle.setPadding(0, dp(20), 0, dp(4))
        col.addView(strictTitle)
        col.addView(tv("لما تفعّله مش هتقدر توقف القفل ولا تغيّر التطبيقات لحد ما المدة تخلص."))

        etMinutes = EditText(this).apply {
            hint = "المدة بالدقايق (مثلاً 60)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        col.addView(etMinutes)

        cbSettings = CheckBox(this).apply {
            text = "امنع تطبيق الإعدادات أثناء الوضع الصارم (عشان ماتقدرش تسحب الصلاحيات). مش هتقدر تفتح الإعدادات لحد ما المدة تخلص."
            isChecked = Prefs.blockSettings(this@MainActivity)
        }
        col.addView(cbSettings)

        strictBtn = Button(this).apply {
            text = "تفعيل الوضع الصارم"
            setOnClickListener { onStrict() }
        }
        col.addView(strictBtn)

        strictTv = tv("", 18f, true)
        col.addView(strictTv)

        val pick = tv("اختار التطبيقات اللي تتقفل:", 16f, true)
        pick.setPadding(0, dp(20), 0, dp(4))
        col.addView(pick)
        return col
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val skip = HashSet<String>(Prefs.homePackages(this))
            skip.add(packageName)
            try {
                val tm = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.defaultDialerPackage?.let { skip.add(it) }
            } catch (_: Exception) {
            }
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val result = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName !in skip }
                .distinctBy { it.activityInfo.packageName }
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps.clear()
                apps.addAll(result)
                adapter.notifyDataSetChanged()
            }
        }.start()
    }

    private fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun permsOk(): Boolean = hasUsage() && Settings.canDrawOverlays(this)

    private fun startLockService() {
        startForegroundService(Intent(this, BlockService::class.java))
    }

    private fun onToggle() {
        if (Prefs.isStrict(this)) return
        if (Prefs.enabled(this)) {
            Prefs.setEnabled(this, false)
            stopService(Intent(this, BlockService::class.java))
        } else {
            if (!permsOk()) {
                Toast.makeText(this, "فعّل الصلاحيات الأول", Toast.LENGTH_SHORT).show()
                return
            }
            if (selected.isEmpty()) {
                Toast.makeText(this, "اختار تطبيق واحد على الأقل", Toast.LENGTH_SHORT).show()
                return
            }
            Prefs.setEnabled(this, true)
            startLockService()
        }
        updateUi()
    }

    private fun onStrict() {
        if (Prefs.isStrict(this)) return
        if (!permsOk()) {
            Toast.makeText(this, "فعّل الصلاحيات الأول", Toast.LENGTH_SHORT).show()
            return
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "اختار تطبيق واحد على الأقل", Toast.LENGTH_SHORT).show()
            return
        }
        val min = etMinutes.text.toString().trim().toLongOrNull() ?: 0L
        if (min < 1 || min > 10080) {
            Toast.makeText(this, "اكتب مدة من 1 لحد 10080 دقيقة (أسبوع)", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("تأكيد الوضع الصارم")
            .setMessage(
                "القفل هيفضل شغال ${min / 60} ساعة و ${min % 60} دقيقة، ومش هتقدر توقفه قبل كده. متأكد؟"
            )
            .setPositiveButton("تفعيل") { _, _ ->
                Prefs.setBlockSettings(this, cbSettings.isChecked)
                Prefs.setStrictUntil(this, System.currentTimeMillis() + min * 60_000L)
                Prefs.setEnabled(this, true)
                startLockService()
                updateUi()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun updateUi() {
        val usage = hasUsage()
        val overlay = Settings.canDrawOverlays(this)
        permsTv.text = "Usage Access: " + (if (usage) "✅" else "❌") +
            "     العرض فوق التطبيقات: " + (if (overlay) "✅" else "❌")
        btnUsage.visibility = if (usage) View.GONE else View.VISIBLE
        btnOverlay.visibility = if (overlay) View.GONE else View.VISIBLE

        val strict = Prefs.isStrict(this)
        toggleBtn.text = if (Prefs.enabled(this) || strict) "⏹ إيقاف القفل" else "▶ تشغيل القفل"
        toggleBtn.isEnabled = !strict
        etMinutes.isEnabled = !strict
        cbSettings.isEnabled = !strict
        strictBtn.isEnabled = !strict
        strictTv.text = if (strict) "🔒 الوضع الصارم شغال — باقي " + Prefs.remainingText(this) else ""

        if (lastStrict != strict) {
            lastStrict = strict
            adapter.notifyDataSetChanged()
        }
    }

    override fun onResume() {
        super.onResume()
        if ((Prefs.enabled(this) || Prefs.isStrict(this)) && permsOk()) {
            startLockService()
        }
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }
}
