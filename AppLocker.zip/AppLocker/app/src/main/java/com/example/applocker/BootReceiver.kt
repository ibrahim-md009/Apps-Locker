package com.example.applocker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs.enabled(context) || Prefs.isStrict(context)) {
            try {
                context.startForegroundService(Intent(context, BlockService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
