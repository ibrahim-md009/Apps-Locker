package com.example.applocker

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

// شاشة القفل (طبقة فوق التطبيق). بتتستخدم من BlockService ومن خدمة إمكانية الوصول
class LockOverlay(
    private val ctx: Context,
    private val windowType: Int,
    private val onHome: () -> Unit
) {
    private var view: View? = null
    private var sub: TextView? = null

    fun show(subText: String) {
        if (view != null) {
            sub?.text = subText
            return
        }
        val pad = (24 * ctx.resources.displayMetrics.density).toInt()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF1E1B4B.toInt(), 0xFF0F172A.toInt())
            )
            isClickable = true
        }
        root.addView(TextView(ctx).apply {
            text = "🔒"
            textSize = 72f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(ctx).apply {
            text = "التطبيق ده مقفول"
            setTextColor(Color.WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
        })
        val s = TextView(ctx).apply {
            setTextColor(0xFFA5B4FC.toInt())
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
            text = subText
        }
        root.addView(s)
        root.addView(Ui.button(ctx, "الرجوع للرئيسية", 0xFF6366F1.toInt()) { onHome() })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(root, lp)
            view = root
            sub = s
        } catch (_: Exception) {
        }
    }

    fun updateText(t: String) {
        sub?.text = t
    }

    fun hide() {
        val v = view ?: return
        try {
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Exception) {
        }
        view = null
        sub = null
    }
}

object Ui {
    fun button(ctx: Context, text: String, color: Int, onClick: () -> Unit): Button =
        Button(ctx).apply {
            this.text = text
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 28f * ctx.resources.displayMetrics.density
            }
            setOnClickListener { onClick() }
        }
}

fun Button.setActive(on: Boolean) {
    isEnabled = on
    alpha = if (on) 1f else 0.45f
}
