package com.example.applocker

import android.content.Context
import android.content.Intent
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("applocker", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> =
        HashSet(sp(c).getStringSet("blocked", emptySet()) ?: emptySet())

    fun setBlocked(c: Context, s: Set<String>) {
        sp(c).edit().putStringSet("blocked", HashSet(s)).apply()
    }

    fun enabled(c: Context): Boolean = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("enabled", v).apply()
    }

    fun strictUntil(c: Context): Long = sp(c).getLong("strictUntil", 0L)
    fun setStrictUntil(c: Context, v: Long) {
        sp(c).edit().putLong("strictUntil", v).apply()
    }

    fun isStrict(c: Context): Boolean = strictUntil(c) > System.currentTimeMillis()

    fun blockSettings(c: Context): Boolean = sp(c).getBoolean("blockSettings", true)
    fun setBlockSettings(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("blockSettings", v).apply()
    }

    fun remainingText(c: Context): String {
        val ms = (strictUntil(c) - System.currentTimeMillis()).coerceAtLeast(0L)
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    // تطبيقات الشاشة الرئيسية (اللانشر): مينفعش تتقفل عشان مانعلقش الموبايل
    fun homePackages(c: Context): Set<String> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return c.packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.packageName }
            .toSet()
    }
}
