package com.example.applocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lastEventTime = 0L
    private var current: String? = null
    private var homePkgs: Set<String> = emptySet()

    private var overlay: View? = null
    private var overlaySub: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            val keepGoing = try {
                poll()
            } catch (_: Exception) {
                true
            }
            if (keepGoing) handler.postDelayed(this, 700)
        }
    }

    override fun onCreate() {
        super.onCreate()
        homePkgs = Prefs.homePackages(this)
        lastEventTime = System.currentTimeMillis() - 3000
        handler.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        hideOverlay()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("lock", "AppLocker", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "lock")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("قفل التطبيقات شغال")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    // بترجع false لو الخدمة وقفت نفسها
    private fun poll(): Boolean {
        val strict = Prefs.isStrict(this)
        if (!Prefs.enabled(this) && !strict) {
            stopSelf()
            return false
        }

        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val from = lastEventTime
        val events = usm.queryEvents(from - 2000, now)
        val e = UsageEvents.Event()
        var newest = from
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.timeStamp <= from) continue
            if (e.timeStamp > newest) newest = e.timeStamp
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                current = e.packageName
            }
        }
        lastEventTime = newest

        val pkg = current
        val blockedNow = if (pkg == null || pkg == packageName || pkg in homePkgs) {
            false
        } else {
            val blocked = HashSet(Prefs.blocked(this))
            if (strict && Prefs.blockSettings(this)) blocked.addAll(SETTINGS_PKGS)
            pkg in blocked
        }

        if (blockedNow) showOverlay() else hideOverlay()
        return true
    }

    private fun subText(): String =
        if (Prefs.isStrict(this)) {
            "الوضع الصارم شغال\nباقي " + Prefs.remainingText(this)
        } else {
            "ركّز في مهامك 💪"
        }

    // شاشة القفل: طبقة كاملة فوق التطبيق (بدون ما نفتح Activity)
    private fun showOverlay() {
        if (overlay != null) {
            overlaySub?.text = subText()
            return
        }
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF111827.toInt())
            isClickable = true
        }
        root.addView(TextView(this).apply {
            text = "🔒"
            textSize = 64f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "التطبيق ده مقفول"
            setTextColor(Color.WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
        })
        val sub = TextView(this).apply {
            setTextColor(0xFF9CA3AF.toInt())
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
            text = subText()
        }
        root.addView(sub)
        root.addView(Button(this).apply {
            text = "الرجوع للرئيسية"
            setOnClickListener { goHome() }
        })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.OPAQUE
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(root, lp)
            overlay = root
            overlaySub = sub
        } catch (_: Exception) {
            // صلاحية العرض فوق التطبيقات ناقصة
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Exception) {
        }
        overlay = null
        overlaySub = null
    }

    private fun goHome() {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    companion object {
        val SETTINGS_PKGS = listOf(
            "com.android.settings",
            "com.android.packageinstaller",
            "com.google.android.packageinstaller"
        )
    }
}
